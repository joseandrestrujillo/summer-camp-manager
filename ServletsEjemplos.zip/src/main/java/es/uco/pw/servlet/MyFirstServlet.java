package es.uco.pw.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

public class MyFirstServlet extends HttpServlet{

	/** Serial ID */
	private static final long serialVersionUID = -8861667687959414409L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>�Bienvenido!</h1>");
		out.println("<p>�Hola mundo!</p>");
		out.close();
	}
}
