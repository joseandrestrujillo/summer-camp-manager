package es.uco.pw.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name="compruebaedad", urlPatterns="/compruebaedad")
public class RequestResponseServlet extends HttpServlet{

	/** Serial ID */
	private static final long serialVersionUID = -5782796844904182648L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nombre = request.getParameter("nombre");
		String edad = request.getParameter("edad");
		
		if(Integer.parseInt(edad)>17) {
			RequestDispatcher disp = request.getRequestDispatcher("helloworld");
			disp.forward(request, response);
		}
		
		else {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("Lo sentimos, " + nombre + " es menor de edad!");
			RequestDispatcher disp = request.getRequestDispatcher("index.html");
			disp.include(request, response);
		}
	}
	
}
